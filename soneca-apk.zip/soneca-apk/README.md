# Soneca (APK)

App Capacitor: o mesmo Soneca da web, mais um alarme nativo do Android que toca no horário final mesmo com o app fechado.

## Gerar o APK sem instalar nada (GitHub Actions)
1. Crie um repositório no GitHub e suba todo o conteúdo desta pasta (branch main).
2. Abra a aba Actions, execute "Build APK" e espere uns 5 minutos.
3. Baixe o artefato "soneca-apk", extraia e instale o app-debug.apk no celular (permita "fontes desconhecidas").

## Gerar localmente (Node 20, JDK 17, Android SDK)
npm install && npx cap add android && bash scripts/patch-android.sh && npx cap sync android && cd android && ./gradlew assembleDebug
APK em android/app/build/outputs/apk/debug/app-debug.apk

## Primeiro uso
Permita notificações, microfone e "Alarmes e lembretes". Nas configurações de bateria do Android, deixe o Soneca como "Sem restrições".

## Limites
- O alarme inteligente (janela de sono leve) roda dentro do app: deixe-o aberto, com o celular carregando. A tela fica acesa.
- O alarme nativo de segurança usa o som do canal de notificações (volume de notificação), por 30 s.
- É um APK de teste (assinatura debug). Para a Play Store é preciso assinar uma versão release.
