#!/usr/bin/env bash
set -e
M=android/app/src/main
mkdir -p $M/res/raw
cp resources/alarme.wav $M/res/raw/alarme.wav
grep -q RECORD_AUDIO $M/AndroidManifest.xml || sed -i '/<\/manifest>/e cat scripts/perms.xml' $M/AndroidManifest.xml
cp scripts/MainActivity.java $M/java/com/soneca/app/MainActivity.java
